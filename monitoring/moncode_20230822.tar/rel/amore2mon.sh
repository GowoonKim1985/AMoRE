#!/bin/bash

while :
do
    python3 /home/gowoon/influxDB/daqmon.py
    python3 /home/gowoon/influxDB/wcmdmon.py    
#    python3 /home/gowoon/influxDB/test.py    
#    python3 /etc/supervisord.d/test.py    
#    echo "test" >/home/gowoon/result.txt
    sleep 600
done    
